<?php 
/*
Plugin Name: SoftHopper Pick Theme Plugin
Plugin URI: http://www.softhopper.net
Description: This plugin will include Pick theme shortcode
Author: SoftHopper
Author URI: http://softhopper.net
Version: 2.0
*/

/* don't call the file directly */
if ( !defined( 'ABSPATH' ) ) exit;

// include shortcode file to generate shortcode from code editor
include( plugin_dir_path( __FILE__ ) . 'shortcodes/shortcodes.php' );

include( plugin_dir_path( __FILE__ ) . 'widgets/widgets.php' );

include( plugin_dir_path( __FILE__ ) . 'inc/featured-post.php' );
include( plugin_dir_path( __FILE__ ) . 'inc/instagram-block.php' );

if ( ! function_exists( 'pick_theme_removeDemoModeLink' ) ) :
// remove redux demo mode link from plugin
function pick_theme_removeDemoModeLink() { // Be sure to rename this function to something more unique
    if ( class_exists('ReduxFrameworkPlugin') ) {
        remove_filter( 'plugin_row_meta', array( ReduxFrameworkPlugin::get_instance(), 'plugin_metalinks'), null, 2 );
    }
    if ( class_exists('ReduxFrameworkPlugin') ) {
        remove_action('admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );    
    }
}
add_action('init', 'pick_theme_removeDemoModeLink');
endif;

/**
 * Removes the demo link and the notice of integrated demo from the redux-framework plugin
 */
if ( ! function_exists( 'remove_demo' ) ) {
    function remove_demo() {
        // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
        if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
            remove_filter( 'plugin_row_meta', array(
                ReduxFrameworkPlugin::instance(),
                'plugin_metalinks'
            ), null, 2 );

            // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
            remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
        }
    }
}

if ( ! function_exists( 'pick_social_share_link' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function pick_social_share_link() { ?>
    <div class="share-button">    
        <script type="text/javascript">
              function pickPopupWindow(url, title, w, h) {
                  var left = (screen.width/2)-(w/2);
                  var top = (screen.height/2)-(h/2);
                  return window.open(url, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+top+', left='+left);
                }   
        </script>     
         <span><?php esc_html_e('Share', 'pick');?></span>                   
        <!-- facebook share -->
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" onclick="pickPopupWindow(this.href, 'facebook-share', 580, 400); return false;"><span class="fa fa-facebook"></span></a>
        <!-- twitter share -->
        <a href="https://twitter.com/home?status=<?php the_permalink(); ?>" onclick="pickPopupWindow(this.href, 'facebook-share', 580, 400); return false;"><span class="fa fa-twitter"></span></a>
        <!-- google plus share -->
        <a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="pickPopupWindow(this.href, 'google-plus-share', 550,530); return false;"><span class="fa fa-google-plus"></span></a>
        <!-- pinterest share -->
        <a href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','http://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());"><span class="fa fa-pinterest-p"></span></a>
        <!-- linkedin share -->
        <a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>" onclick="pickPopupWindow(this.href, 'linkedin-share', 550,530); return false;"><span class="fa fa-linkedin"></span></a>
    </div><!-- /.share-button -->
    <?php
}
endif;