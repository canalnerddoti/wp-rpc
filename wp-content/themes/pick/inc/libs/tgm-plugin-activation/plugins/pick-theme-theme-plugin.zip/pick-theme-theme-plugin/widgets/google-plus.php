<?php 
/* forked from : Plugin URI: http://wordpress.org/plugins/new-google-plus-badge-widget/
   Thanks To : MyThemeShop and Suraj Vibhute
*/

class Pick_Theme_Googleplus extends WP_Widget {

	function __construct() {
	    $params = array (
	        'description' => esc_html__('Pick : Google Plus Widget', 'pick'),
	        'name' => esc_html__('Pick : Google Plus', 'pick')
	    );
	    parent::__construct('Pick_Theme_Googleplus','',$params);
	}

	var $langs = array(
		'af' => 'Afrikaans',
		'am' => 'Amharic',
		'ar' => 'Arabic',
		'eu' => 'Basque',
		'bn' => 'Bengali',
		'bg' => 'Bulgarian',
		'ca' => 'Catalan',
		'zh-HK' => 'Chinese (Hong Kong)',
		'zh-CN' => 'Chinese (Simplified)',
		'zh-TW' => 'Chinese (Traditional)',
		'hr' => 'Croatian',
		'cs' => 'Czech',
		'da' => 'Danish',
		'nl' => 'Dutch',
		'en-GB' => 'English (UK)',
		'en-US' => 'English (US)',
		'et' => 'Estonian',
		'fil' => 'Filipino',
		'fi' => 'Finnish',
		'fr' => 'French',
		'fr-CA' => 'French (Canadian)',
		'gl' => 'Galician',
		'de' => 'German',
		'el' => 'Greek',
		'gu' => 'Gujarati',
		'iw' => 'Hebrew',
		'hi' => 'Hindi',
		'hu' => 'Hungarian',
		'is' => 'Icelandic',
		'id' => 'Indonesian',
		'it' => 'Italian',
		'ja' => 'Japanese',
		'kn' => 'Kannada',
		'ko' => 'Korean',
		'lv' => 'Latvian',
		'lt' => 'Lithuanian',
		'ms' => 'Malay',
		'ml' => 'Malayalam',
		'mr' => 'Marathi',
		'no' => 'Norwegian',
		'fa' => 'Persian',
		'pl' => 'Polish',
		'pt-BR' => 'Portuguese (Brazil)',
		'pt-PT' => 'Portuguese (Portugal)',
		'ro' => 'Romanian',
		'ru' => 'Russian',
		'sr' => 'Serbian',
		'sk' => 'Slovak',
		'sl' => 'Slovenian',
		'es' => 'Spanish',
		'es-419' => 'Spanish (Latin America)',
		'sw' => 'Swahili',
		'sv' => 'Swedish',
		'ta' => 'Tamil',
		'te' => 'Telugu',
		'th' => 'Thai',
		'tr' => 'Turkish',
		'uk' => 'Ukrainian',
		'ur' => 'Urdu',
		'vi' => 'Vietnamese',
		'zu' => 'Zulu',
	);


	function widget($args, $instance)
	{
		extract($args);

		$title = apply_filters('widget_title', $instance['title']);		
		$page_type = $instance['page_type'];
		$page_url = $instance['page_url'];
		$width = $instance['width'];
		$color_scheme = $instance['color_scheme'];
		$gp_layout = $instance['gp_layout'];
		$cover_photo = isset($instance['cover_photo']) ? 'true' : 'false';
		$tagline = isset($instance['tagline']) ? 'true' : 'false';
		$lang = $instance['lang'];
		echo $before_widget;

		if($title) {
			echo $before_title.$title.$after_title;
		}
		?>
			<div class="pick-theme-googleplus-widget">
				<div class="mgw-inner">
					<?php
					if($page_url): ?>	
						<div <?php if($page_type == 'profile') { ?>class="g-person"<?php } elseif($page_type == 'page') { ?>class="g-page"<?php } elseif($page_type == 'community') { ?>class="g-community"<?php } ?> data-width="<?php echo esc_attr($width); ?>" data-href="<?php echo esc_url($page_url); ?>" data-layout="<?php echo esc_attr($gp_layout); ?>" data-theme="<?php echo esc_attr($color_scheme); ?>" data-rel="publisher" data-showtagline="<?php echo esc_attr($tagline); ?>" data-showcoverphoto="<?php echo esc_attr($cover_photo); ?>"></div>
						<!-- Place this tag after the last badgev2 tag. -->
						<script type="text/javascript">
							var lang = '<?php echo esc_js($lang); ?>';
							if (lang !== '') {
								 window.___gcfg = {lang: lang};
							}
						  (function() {
							var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
							po.src = 'https://apis.google.com/js/plusone.js';
							var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
						  })();
						</script>
					<?php endif;
					?>
				</div>		
				<div class="mgw-cover"></div>
			</div>

		<?php
		echo $after_widget;
	}
	
	function update($new_instance, $old_instance){
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['page_type'] = $new_instance['page_type'];
		$instance['page_url'] = $new_instance['page_url'];
		$instance['width'] = $new_instance['width'];
		$instance['gp_layout'] = $new_instance['gp_layout'];
		$instance['color_scheme'] = $new_instance['color_scheme'];
		$instance['cover_photo'] = $new_instance['cover_photo'];
		$instance['tagline'] = $new_instance['tagline'];
		$instance['lang'] = $new_instance['lang'];
		
		return $instance;
	}


	 /** @see WP_Widget::form */
	function form($instance)
	{
		$defaults = array(
				'title' => esc_html__('Google+','pick'), 
				'page_url' => 'https://plus.google.com/+envato', 
				'width' => '295', 
				'color_scheme' => 'light', 
				'gp_layout' => 'portrait', 
				'page_type' => 'profile', 
				'cover_photo' => 'on', 
				'tagline' => 'on', 
				'lang' => ''
			);
		$instance = wp_parse_args((array) $instance, $defaults); ?>

		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title','pick'); ?>:</label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php if( isset($instance['title']) ) echo esc_attr($instance['title']); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr($this->get_field_id('page_type')); ?>"><?php esc_html_e('Page type','pick'); ?>:</label> 
			<select id="<?php echo esc_attr($this->get_field_id('page_type')); ?>" name="<?php echo esc_attr($this->get_field_name('page_type')); ?>" class="widefat">
				<option <?php if ('profile' == $instance['page_type']) echo 'selected="selected"'; ?>><?php esc_html_e('profile','pick'); ?></option>
				<option <?php if ('page' == $instance['page_type']) echo 'selected="selected"'; ?>><?php esc_html_e('page','pick'); ?></option>
				<option <?php if ('community' == $instance['page_type']) echo 'selected="selected"'; ?>><?php esc_html_e('community','pick'); ?></option>
			</select>
		</p>		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('page_url')); ?>"><?php esc_html_e('Google+ Page URL','pick'); ?>:</label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('page_url')); ?>" name="<?php echo esc_attr($this->get_field_name('page_url')); ?>" value="<?php if( isset($instance['page_url']) ) echo esc_url($instance['page_url']); ?>" />
		</p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('width')); ?>"><?php esc_html_e('Width','pick'); ?>:</label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('width')); ?>" name="<?php echo esc_attr($this->get_field_name('width')); ?>" value="<?php if( isset($instance['width']) ) echo esc_attr($instance['width']); ?>" />
		</p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('color_scheme')); ?>"><?php esc_html_e('Color Scheme','pick'); ?>:</label> 
			<select id="<?php echo esc_attr($this->get_field_id('color_scheme')); ?>" name="<?php echo esc_attr($this->get_field_name('color_scheme')); ?>" class="widefat">
				<option value="light" <?php selected($instance['color_scheme'], 'light'); ?>><?php esc_html_e('Light', 'pick'); ?></option>
				<option value="dark" <?php selected($instance['color_scheme'], 'dark'); ?>><?php esc_html_e('Dark', 'pick'); ?></option>
			</select>
		</p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('gp_layout')); ?>"><?php esc_html_e('Layout','pick'); ?>:</label> 
			<select id="<?php echo esc_attr($this->get_field_id('gp_layout')); ?>" name="<?php echo esc_attr($this->get_field_name('gp_layout')); ?>" class="widefat">
				<option value="portrait" <?php selected($instance['gp_layout'], 'portrait'); ?>><?php esc_html_e('Portrait', 'pick'); ?></option>
				<option value="landscape" <?php selected($instance['gp_layout'], 'landscape'); ?>><?php esc_html_e('Landscape', 'pick'); ?></option>
			</select>
		</p>
		
		<p>
			<b><?php esc_html_e('Portrait Layout Settings','pick'); ?></b>
		</p>
		
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['cover_photo'], 'on'); ?> id="<?php echo esc_attr($this->get_field_id('cover_photo')); ?>" name="<?php echo esc_attr($this->get_field_name('cover_photo')); ?>" /> 
			<label for="<?php echo esc_attr($this->get_field_id('cover_photo')); ?>"><?php esc_html_e('Cover Photo','pick'); ?></label>
		</p>
		
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['tagline'], 'on'); ?> id="<?php echo esc_attr($this->get_field_id('tagline')); ?>" name="<?php echo esc_attr($this->get_field_name('tagline')); ?>" /> 
			<label for="<?php echo esc_attr($this->get_field_id('tagline')); ?>"><?php esc_html_e('Tagline','pick'); ?></label>
		</p>

		<p>
			<label for="<?php echo esc_attr($this->get_field_id('lang')); ?>"><?php esc_html_e('Language','pick'); ?>:</label> 
			<select id="<?php echo esc_attr($this->get_field_id('lang')); ?>" name="<?php echo esc_attr($this->get_field_name('lang')); ?>" style="width:100%;">
			<option value=""><?php esc_html_e('Select Language ...', 'pick'); ?></option>
			<?php foreach ($this->langs as $code => $name) { ?>
				<option value="<?php echo esc_attr($code); ?>" <?php selected($instance['lang'], $code); ?>><?php echo esc_html($name); ?></option>
			<?php } ?>
			</select>
		</p>
		
	<?php
	}
} // class end 