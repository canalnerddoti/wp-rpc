(function() {
	tinymce.PluginManager.add('pick_mce_button', function( editor, url ) {
		editor.addButton( 'pick_mce_button', {
            icon: ' pick-shortcodes-icon ',
			tooltip: pickLang.shortcode_picklabs,
			type: 'menubutton',
			minWidth: 210,
			menu: [
				{
					text: pickLang.shortcode_button,
					onclick: function() {
						editor.windowManager.open( {
							title: pickLang.shortcode_button,
							body: [
								{
									type: 'listbox',
									name: 'ButtonType',
									label: pickLang.shortcode_type,
									'values': [
										{text: pickLang.shortcode_default, value: 'btn-default'},
										{text: pickLang.shortcode_primary, value: 'btn-primary'},
										{text: pickLang.shortcode_success, value: 'btn-success'},
										{text: pickLang.shortcode_info, value: 'btn-info'},
										{text: pickLang.shortcode_warning, value: 'btn-warning'},
										{text: pickLang.shortcode_danger, value: 'btn-danger'},
									]
								},
								{
									type: 'listbox',
									name: 'ButtonSize',
									label: pickLang.shortcode_size,
									'values': [
										{text: pickLang.shortcode_size_large, value: 'btn-lg'},
										{text: pickLang.shortcode_size_default, value: ''},
										{text: pickLang.shortcode_size_small, value: 'btn-sm'},
										{text: pickLang.shortcode_size_ex_small, value: 'btn-xs'},
									]
								},
								{
									type: 'textbox',
									name: 'ButtonText',
									label: pickLang.shortcode_text,
									minWidth: 300,
									value: ''
								},
							],
							onsubmit: function( e ) {
								editor.insertContent( '[button type="' + e.data.ButtonType + '" size="' + e.data.ButtonSize + '" text="' + e.data.ButtonText + '"]');
							}
						});
					}
				},
				{
					text: pickLang.shortcode_progressbar,
					onclick: function() {
						editor.windowManager.open( {
							title: pickLang.shortcode_progressbar,
							body: [
								{
									type: 'listbox',
									name: 'ProgressbarType',
									label: pickLang.shortcode_type,
									'values': [
										{text: pickLang.shortcode_default, value: 'default'},
										{text: pickLang.shortcode_primary, value: 'primary'},
										{text: pickLang.shortcode_success, value: 'success'},
										{text: pickLang.shortcode_info, value: 'info'},
										{text: pickLang.shortcode_warning, value: 'warning'},
										{text: pickLang.shortcode_danger, value: 'danger'},
									]
								},
								{
									type: 'textbox',
									name: 'ProgressbarWidth',
									label: pickLang.shortcode_width,
									minWidth: 300,
									value: '50'
								},
								{
									type: 'textbox',
									name: 'ProgressbarTitle',
									label: pickLang.shortcode_title,
									minWidth: 300,
									value: ''
								},
								{
									type: 'listbox',
									name: 'ProgressbarStriped',
									label: pickLang.shortcode_striped,
									'values': [
										{text: pickLang.shortcode_true, value: 'true'},
										{text: pickLang.shortcode_false, value: 'false'},
									]
								},
								{
									type: 'listbox',
									name: 'ProgressbarAnimation',
									label: pickLang.shortcode_animation,
									'values': [
										{text: pickLang.shortcode_true, value: 'true'},
										{text: pickLang.shortcode_false, value: 'false'},
									]
								},
							],
							onsubmit: function( e ) {
								editor.insertContent( '[progress_bar type="' + e.data.ProgressbarType + '" width="' + e.data.ProgressbarWidth + '" title="' + e.data.ProgressbarTitle + '" striped="' + e.data.ProgressbarStriped + '" animation="' + e.data.ProgressbarAnimation + '"]');
							}
						});
					}
				},
				{
					text: pickLang.shortcode_status,
					onclick: function() {
						editor.windowManager.open( {
							title: pickLang.shortcode_status,
							body: [
								{
									type: 'listbox',
									name: 'StatusType',
									label: pickLang.shortcode_type,
									'values': [
										{text: pickLang.shortcode_facebook, value: 'facebook'},
										{text: pickLang.shortcode_tweeter, value: 'tweeter'},
										{text: pickLang.shortcode_google_plus, value: 'google_plus'},
									]
								},
								{
									type: 'textbox',
									name: 'StatusURL',
									label: pickLang.shortcode_url,
									minWidth: 300,
									value: ''
								},
								{
									type: 'textbox',
									name: 'StatusBackground',
									label: pickLang.shortcode_background_img,
									minWidth: 300,
									value: ''
								},
							],
							onsubmit: function( e ) {
								editor.insertContent( '[status type="' + e.data.StatusType + '" url="' + e.data.StatusURL + '" background="' + e.data.StatusBackground + '"]');
							}
						});
					}
				},
				{
					text: pickLang.shortcode_alert,
					onclick: function() {
						editor.windowManager.open( {
							title: pickLang.shortcode_alert,
							body: [
								{
									type: 'listbox',
									name: 'AlertType',
									label: pickLang.shortcode_type,
									'values': [
										{text: pickLang.shortcode_default, value: 'default'},
										{text: pickLang.shortcode_primary, value: 'primary'},
										{text: pickLang.shortcode_success, value: 'success'},
										{text: pickLang.shortcode_info, value: 'info'},
										{text: pickLang.shortcode_warning, value: 'warning'},
										{text: pickLang.shortcode_danger, value: 'danger'},
									]
								},
								{
									type: 'listbox',
									name: 'AlertDismiss',
									label: pickLang.shortcode_dismiss,
									'values': [
										{text: pickLang.shortcode_true, value: 'true'},
										{text: pickLang.shortcode_false, value: 'false'},
									]
								},
								{
									type: 'textbox',
									name: 'AlertContent',
									label: pickLang.shortcode_content,
									value: '',									
									multiline: true,
									minWidth: 300,
									minHeight: 100
								},
							],
							onsubmit: function( e ) {
								editor.insertContent( '[alert type="' + e.data.AlertType + '" dismiss="' + e.data.AlertDismiss + '"]' + e.data.AlertContent + '[/alert]');
							}
						});
					}
				},
				{
					text: pickLang.shortcode_video,
					onclick: function() {
						editor.windowManager.open( {
							title: pickLang.shortcode_video,
							body: [
								{
									type: 'textbox',
									name: 'VideoURL',
									label: pickLang.shortcode_video_url,
									value: 'http://',
									minWidth: 300,
								},
								{
									type: 'textbox',
									name: 'VideoWidth',
									label: pickLang.shortcode_width,
									value: ''
								},
								{
									type: 'textbox',
									name: 'Videoheight',
									label: pickLang.shortcode_height,
									value: ''
								},
							],
							onsubmit: function( e ) {
								editor.insertContent( '[embed width="' + e.data.VideoWidth + '" height="' + e.data.Videoheight + '"]' + e.data.VideoURL + '[/embed]');
							}
						});
					}
				},
				{
					text: pickLang.shortcode_audio,
					onclick: function() {
						editor.windowManager.open( {
							title: pickLang.shortcode_audio,
							body: [
								{
									type: 'textbox',
									name: 'mp3URL',
									label: pickLang.shortcode_mp3,
									value: 'http://',
									minWidth: 300,
								},
								{
									type: 'textbox',
									name: 'm4aURL',
									label: pickLang.shortcode_m4a,
									value: 'http://',
									minWidth: 300,
								},
								{
									type: 'textbox',
									name: 'oggURL',
									label: pickLang.shortcode_ogg,
									value: 'http://',
									minWidth: 300,
								},
								
							],
							onsubmit: function( e ) {
								editor.insertContent( '[audio mp3="' + e.data.mp3URL + '" m4a="' + e.data.m4aURL + '" ogg="' + e.data.oggURL + '"]');
							}
						});
					}
				},
				{
					text: pickLang.shortcode_tooltip,
					onclick: function() {
						editor.windowManager.open( {
							title: pickLang.shortcode_tooltip,
							body: [
								{
									type: 'textbox',
									name: 'TooltipText',
									label: pickLang.shortcode_text,
									value: '',
									minWidth: 300,
								},
								{
									type: 'listbox',
									name: 'TooltipDirection',
									label: pickLang.shortcode_direction,
									'values': [
										{text: pickLang.shortcode_top, value: 'top'},
										{text: pickLang.shortcode_right, value: 'right'},
										{text: pickLang.shortcode_bottom, value: 'bottom'},
										{text: pickLang.shortcode_left, value: 'left'},
									]
								},
								{
									type: 'textbox',
									name: 'ToolTipContent',
									label: pickLang.shortcode_content,
									value: '',
									multiline: true,
									minWidth: 300,
									minHeight: 100
								}
								
							],
							onsubmit: function( e ) {
								editor.insertContent( '[tooltip text="' + e.data.TooltipText + '" direction="' + e.data.TooltipDirection + '"]'+ e.data.ToolTipContent +'[/tooltip]');
							}
						});
					}
				},
				{
					text: pickLang.shortcode_columns,
						onclick: function() {
							editor.insertContent( '\
							[row]<br />\
								[column number="6" offset=""] Column Content Goes Here [/column]<br />\
								[column number="6" offset=""] Column Content Goes Here [/column]<br />\
							[/row]');
						}
				},
				{
					text: pickLang.shortcode_accordion,
						onclick: function() {
							editor.insertContent( '\
							[collapse_group]<br />\
								[collapse id="accordion_one" title="Accordion Title" expanded="false"] Accordion Content [/collapse]<br />\
								[collapse id="accordion_two" title="Accordion Title" expanded="false"] Accordion Content [/collapse]<br />\
							[/collapse_group]');
						}
				},
				{
					text: pickLang.shortcode_tab,
						onclick: function() {
							editor.insertContent( '\
							[tabs]<br />\
								[tab id="tab_one" title="Tab Title" active="active"] Tab Content [/tab]<br />\
								[tab id="tab_two" title="Tab Title"] Tab Content [/tab]<br />\
								[tab id="tab_three" title="Tab Title"] Tab Content [/tab]<br />\
							[/tabs]');
						}
				},
			]
		});
	});
})();