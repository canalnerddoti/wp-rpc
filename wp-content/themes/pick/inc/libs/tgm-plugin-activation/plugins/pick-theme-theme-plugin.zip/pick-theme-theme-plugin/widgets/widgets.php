<?php
/**
 * Load and register widgets
 *
 * @package Pick
 */

require_once plugin_dir_path( __FILE__ ) . 'popular-posts.php';
require_once plugin_dir_path( __FILE__ ) . 'latest-posts.php';
require_once plugin_dir_path( __FILE__ ) . 'about-me.php';
require_once plugin_dir_path( __FILE__ ) . 'follow-me.php';
require_once plugin_dir_path( __FILE__ ) . 'advertisement.php';
require_once plugin_dir_path( __FILE__ ) . 'aboutus-contact.php';
require_once plugin_dir_path( __FILE__ ) . 'facebook-likebox.php';
require_once plugin_dir_path( __FILE__ ) . 'google-plus.php';
require_once plugin_dir_path( __FILE__ ) . 'twitter-feed.php';
require_once plugin_dir_path( __FILE__ ) . 'flickr.php';
require_once plugin_dir_path( __FILE__ ) . 'newsletter.php';
require_once plugin_dir_path( __FILE__ ) . 'recent-comments.php';
require_once plugin_dir_path( __FILE__ ) . 'loginform.php';

/**
 * Register widgets
 *
 */

add_action('widgets_init','pick_theme_register_widgets');
function pick_theme_register_widgets() {
	register_widget('Pick_Theme_Popular_Posts');
	register_widget('Pick_Theme_Latest_Posts');
	register_widget('Pick_Theme_About_Me');
	register_widget('Pick_Theme_Follow_Me');
	register_widget('Pick_Theme_Advertisement');
	register_widget('Pick_Theme_Aboutus_Contact');
	register_widget('Pick_Theme_Fb_Likebox');
	register_widget('Pick_Theme_Googleplus');
	register_widget('Pick_Theme_Twitter_Feed');
	register_widget('Pick_Theme_Flickr_Gallery');
	register_widget('Pick_Theme_Newsletter');
	register_widget('Pick_Theme_Comments');
	register_widget('Pick_Theme_Login_Form');
}






