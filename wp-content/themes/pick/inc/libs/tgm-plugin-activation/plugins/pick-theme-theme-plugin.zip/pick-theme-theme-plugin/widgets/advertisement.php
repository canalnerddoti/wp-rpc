<?php
class Pick_Theme_Advertisement extends WP_Widget {

    function __construct() {
        $params = array (
            'description' => esc_html__('Pick : Advertisement Widget', 'pick'),
            'name' => esc_html__('Pick : Advertisement', 'pick')
        );
        parent::__construct('Pick_Theme_Advertisement','',$params);
    }

    /** @see WP_Widget::form */
    public function form( $instance) {
        extract($instance);
        ?>        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:','pick'); ?></label>
            <input
                class="widefat"
                type="text"
                id="<?php echo esc_attr($this->get_field_id('title')); ?>"
                name="<?php echo esc_attr($this->get_field_name('title')); ?>"
                value="<?php if( isset($title) ) echo esc_attr($title); ?>" />
        </p> 
        <p>
           <label class="ad-img-lebel"><?php esc_html_e('Ad Image:','pick'); ?></label>       
        <?php
          $arg = array(       
            'parent_div_class'=> 'custom-image-upload',                    
            'field_name' => $this->get_field_name('image'),
            'field_id' => 'upload_logo',
            'field_class' => 'upload_image_field',
            
            'upload_button_id' => 'upload_logo_button',
            'upload_button_class' => 'upload_logo_button',
            'upload_button_text' => 'Upload',
            
            'remove_button_id' => 'remove_logo',
            'remove_button_class' => 'remove_logo_button',
            'remove_button_text' => 'Remove'
            
            );
           if ( empty($image) ) $image = NULL;
           pick_theme_ad_media_custom($arg,false,$image);
        ?>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('ad_url')); ?>"><?php esc_html_e('Ad URL:','pick'); ?></label>
            <input
                class="widefat"
                type="text"
                id="<?php echo esc_attr($this->get_field_id('ad_url')); ?>"
                name="<?php echo esc_attr($this->get_field_name('ad_url')); ?>"
                value="<?php if( isset($ad_url) ) echo esc_url($ad_url); ?>" />
        </p>
      <?php       
    } // end form function

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        //Strip tags from title and name to remove HTML
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['image'] = strip_tags( $new_instance['image'] );
        $instance['ad_url'] = strip_tags( $new_instance['ad_url'] );
     
        return $instance;
    }

    public function widget($args, $instance) {
        extract($args);
        extract($instance);
        $title = apply_filters('widget_title', $title);
        $ad_url = apply_filters('widget_ad_url', $ad_url);
        $image = apply_filters('widget_image', $image);
        
       
        echo $before_widget;
            if ( !empty( $title ) ) {
                echo $before_title . $title . $after_title;
            }
            ?>
            <div class="advertisement-img">                    
                <?php 
                    if ( !empty( $image ) ) {
                         if ( !empty( $ad_url ) ) {
                            echo "<a class='advertisement-link' href='".esc_url($ad_url)."'><img class='img-responsive' src='".esc_url($image)."' alt='Ad Image' /></a>";
                        } else {
                            echo "<img class='img-responsive' src='".esc_url($image)."' alt='Ad Image' />";
                        }
                    }
                ?>
            </div> <!-- /.ad-img -->                
            <?php
        echo $after_widget;
    } // end widget function
    

} // class Cycle Widget

?>
<?php function pick_theme_ad_media_custom( $arg, $use_custom_buttons = false, $value = "" ){
    
    $defaults = array(
        'useid' => false ,
        'hidden' => true,
        
        'parent_div_class'=> 'custom-image-upload',
        
        'field_label' => 'upload_image_field_label',        
        'field_name' => 'upload_image_field',
        'field_id' => 'upload_image_field',
        'field_class' => 'upload_image_field',
        
        'upload_button_id' => 'upload_logo_button',
        'upload_button_class' => 'upload_logo_button',
        'upload_button_text' => 'Upload',
        
        'remove_button_id' => 'remove_logo_button',
        'remove_button_class' => 'remove_logo_button',
        'remove_button_text' => 'Remove',
        
        'preview_div_class' => 'preview',
        'preview_div_class2' => 'preview remove_box',
        'preview_div_id' => 'preview',
        
        'height' => '100',
        'width' => '100'
                    );
        $arguments = wp_parse_args($arg,$defaults);
        
        extract($arguments);
        wp_enqueue_media();
    ?>                                   
   <?php if( ! $use_custom_buttons ): ?>
   <div class="<?php echo esc_attr($parent_div_class); ?>" id="<?php echo esc_attr($parent_div_class); ?>">
   
        <input name="<?php echo esc_attr($field_name); ?>" id="<?php echo esc_attr($field_id); ?>" class="<?php echo esc_attr($field_class); ?>" <?php if($hidden): ?>  type="hidden" <?php else: ?> type="text" <?php endif; ?> value="<?php if ( $value != "") { echo stripslashes($value); }  ?>" />
        
        <input type="button" class="button button-primary <?php echo esc_attr($upload_button_class); ?>" id="<?php echo esc_attr($upload_button_id); ?>"  value="<?php echo esc_attr($upload_button_text); ?>">
        
        <input type="button" class="button button-primary <?php echo esc_attr($remove_button_class); ?>" id="<?php echo esc_attr($remove_button_id); ?>" <?php  if ( $value == "") {  ?> disabled="disabled" <?php } ?> value="<?php echo esc_attr($remove_button_text); ?>">
        
        <div class="<?php echo esc_attr($preview_div_class); ?>" style="float: none; <?php  if ( $value == "") { ?> display: none; <?php } ?>">
            <img src="<?php  echo esc_url($value);  ?>" style="margin: 10px;" width="150" height="100" alt="<?php echo esc_attr($upload_button_text); ?>">
        </div>   
        <div style="clear: both;"></div>
    </div>
   <?php endif; ?>
    <?php
        $usesep = ($useid) ? "#" : ".";
        if($useid):
        
         $field_class = $field_id;
         $upload_button_class = $upload_button_id;
         $remove_button_class = $remove_button_id;
         $preview_div_class = $preview_div_id;
            
        endif;  
    ?>
    <script type="text/javascript">

    jQuery(document).ready(function($){
        $('<?php echo esc_js($usesep.$remove_button_class); ?>').on('click', function(e) {
            <?php if(!$useid): ?>
           $(this).parent().find("<?php echo esc_js($usesep.$field_class); ?>").val(""); 
           $(this).parent().find("<?php echo esc_js($usesep.$preview_div_class); ?> img").attr("src","").fadeOut("fast");
           <?php else: ?>
           $("<?php echo esc_js($usesep.$field_class); ?>").val(""); 
           $("<?php echo esc_js($usesep.$preview_div_class); ?> img").attr("src","").fadeOut("fast");
           <?php endif; ?>
           $(this).attr("disabled","disabled");
         return false;   
        });
        var _custom_media = true,
          _orig_send_attachment = wp.media.editor.send.attachment;

      $('<?php echo esc_js($usesep.$upload_button_class); ?>').on('click', function(e) {
        var send_attachment_bkp = wp.media.editor.send.attachment;
        var button = $(this);
        var id = button.attr('id').replace('_button', '');
        _custom_media = true;
        wp.media.editor.send.attachment = function(props, attachment){
          if ( _custom_media ) {
              
              <?php if(!$useid): ?>
            button.parent().find("<?php echo esc_js($usesep.$field_class); ?>").val(attachment.url);
            button.parent().find("<?php echo esc_js($usesep.$preview_div_class); ?> img").attr("src",attachment.url).fadeIn("fast");
            button.parent().find("<?php echo esc_js($usesep.$remove_button_class); ?>").removeAttr("disabled");
            if($('.preview img').length > 0){ $('.preview').css('display','block'); };
            <?php else: ?>
            $("<?php echo esc_js($usesep.$field_class); ?>").val(attachment.url);
            $("<?php echo esc_js($usesep.$preview_div_class); ?> img").attr("src",attachment.url).fadeIn("fast");        
            $("<?php echo esc_js($usesep.$remove_button_class); ?>").removeAttr("disabled");
            <?php endif; ?>
          } else {
            return _orig_send_attachment.apply( this, [props, attachment] );
          };
          $('.preview').removeClass('remove_box');
        }

        wp.media.editor.open(button);
        return false;
      });
    });        
    </script>
   <?php  
}