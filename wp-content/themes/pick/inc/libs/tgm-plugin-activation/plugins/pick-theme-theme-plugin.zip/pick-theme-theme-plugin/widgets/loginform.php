<?php 

class Pick_Theme_Login_Form extends WP_Widget {

    function __construct() {
        $params = array (
            'description' => esc_html__('Pick : Customized Login Form', 'pick'),
            'name' => esc_html__('Pick : Login Form', 'pick')
        );
        parent::__construct('Pick_Theme_Login_Form','',$params);
    }   

    function widget( $args, $instance ) {
        extract( $args );
        /* User-selected settings. */
        $title = apply_filters('widget_title', $instance['title'] );

        /* Before widget (defined by themes). */
        echo $before_widget;

        /* Title of widget (before and after defined by themes). */
        if ( $title ) {
            echo $before_title . $title . $after_title;
        }

        ?>
        <div class="pick-theme-login-form">

        <?php 

            if ( ! is_user_logged_in() ) {

                wp_login_form( $args );
                echo '<p class="lost-pass"><a href="'. wp_lostpassword_url().'" title="'.esc_html__('Lost Password', 'pick').'">'.esc_html__('Lost Your Password?', 'pick').'</a></p>';
                wp_register( "", "", true );

            } else {
                ?>
                    <div class="pick-theme-login-board">
                       <div class="left-thumb">
                           <?php echo get_avatar( get_the_author_meta('ID')); ?>
                       </div> <!-- / . left-thumb -->
                       <div class="right-details">
                           <p><?php esc_html_e( "Welcome:", "pick" );?> <strong><?php echo get_the_author_meta('display_name');?></strong></p>
                           <div class="dashboard-link">
                                <i class="fa fa-tachometer"></i><a href="<?php echo home_url() ; ?>/wp-admin"><?php esc_html_e( "Dashboard","pick" );?></a>
                           </div>
                           <div class="your-profile">
                                <i class="fa fa-user"></i><a href="<?php echo get_edit_user_link( get_the_author_meta('ID') ) ?>"><?php esc_html_e( "Profile", "pick" );?></a>
                           </div>
                           <div class="logout-link">
                                <i class="fa fa-power-off"></i><a href="<?php echo wp_logout_url( home_url() ); ?>"><?php esc_html_e( "Logout", "pick" );?></a>
                           </div>
                       </div> <!-- / . right-details -->
                   </div> <!-- / .pick-theme-login-board -->
                <?php
            }

       echo "</div> <!-- / .pick-theme-login-form -->";

        /* After widget (defined by themes). */
        echo $after_widget;
    }
    
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        /* Strip tags (if needed) and update the widget settings. */
        $instance['title'] = strip_tags( $new_instance['title'] );
        return $instance;
    }
    
     /** @see WP_Widget::form */
    function form( $instance ) {

            /* Set up some default widget settings. */
            $defaults = array(
                'title' => esc_html__('Login Form', 'pick'),
                );
            $instance = wp_parse_args( (array) $instance, $defaults ); ?>
        
            <p>
                <label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e('Title:', 'pick') ?></label>
                <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" value="<?php if( isset($instance['title']) ) echo esc_attr($instance['title']); ?>" />
            </p>
        
       <?php 
    }
} //end class